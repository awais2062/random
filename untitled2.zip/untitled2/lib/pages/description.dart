import 'package:flutter/material.dart';
import '../data/property.dart';
import 'property_info.dart';

class Description extends StatefulWidget {
  final Property property;
  const Description({super.key, required this.property});

  @override
  _DescriptionState createState() => _DescriptionState();
}

class _DescriptionState extends State<Description> with TickerProviderStateMixin {
  late AnimationController _scaleController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(
        duration: const Duration(seconds: 1), vsync: this);
    _scaleAnimation = CurvedAnimation(parent: _scaleController, curve: Curves.easeIn);
    Future.delayed(const Duration(milliseconds: 500), () {
      _scaleController.forward();
    });
  }

  @override
  void dispose() {
    _scaleController.dispose();
    super.dispose();
  }

  // GestureDetector to detect taps, double taps, and long presses
  GestureDetector _buildGestureDetector() {
    return GestureDetector(
      onTap: () {
        print('onTap for ${widget.property.name}');
        _displayGestureDetected('onTap for ${widget.property.name}');
      },
      onDoubleTap: () {
        print('onDoubleTap for ${widget.property.name}');
        _displayGestureDetected('onDoubleTap for ${widget.property.name}');
      },
      onLongPress: () {
        print('onLongPress for ${widget.property.name}');
        _displayGestureDetected('onLongPress for ${widget.property.name}');
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.property.name),
          backgroundColor: Colors.teal[300],
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.share),
              onPressed: () {},
            ),
          ],
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                FadeTransition(
                  opacity: _scaleAnimation,
                  child: Image.asset(
                    widget.property.image,
                    width: 200,
                    height: 200,
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  widget.property.name,
                  style: const TextStyle(
                      fontSize: 28, fontWeight: FontWeight.bold, color: Colors.black),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),
                Text(
                  widget.property.description,
                  style: const TextStyle(fontSize: 20, color: Colors.grey),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Property_info(property: widget.property),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.teal[300]),
                  icon: const Icon(Icons.info_outline),
                  label: const Text('View More Info'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Method to show the detected gesture using a SnackBar
  void _displayGestureDetected(String gesture) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Gesture Detected: $gesture')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return _buildGestureDetector(); // Wrapping the whole body with GestureDetector
  }
}
